// SPDX-FileCopyrightText: (c) 2023-2026 Shawn Silverman <shawn@pobox.com>
// SPDX-License-Identifier: AGPL-3.0-or-later

// default_altcp_functions.cpp provides default implementations of QNEthernet's
// altcp interface functions.
// This file is part of the QNEthernet library.

#include "lwip/opt.h"
#include "qnethernet_opts.h"

#if LWIP_ALTCP && QNETHERNET_PROVIDE_ALTCP_DEFAULT_FUNCTIONS

// C++ includes
#include <cstdint>
#include <functional>

#include "lwip/altcp.h"
#include "lwip/altcp_tcp.h"
#include "lwip/ip_addr.h"
#include "qnethernet/compat/c++11_compat.h"

// This implementation uses the TCP allocator and returns true.
ATTRIBUTE_WEAK
std::function<bool(const ip_addr_t*, uint16_t, altcp_allocator_t&)>
    qnethernet_altcp_get_allocator = [](const ip_addr_t* const ipaddr,
                                        const uint16_t port,
                                        altcp_allocator_t& allocator) {
      (void)ipaddr;
      (void)port;

      allocator.alloc = &altcp_tcp_alloc;
      allocator.arg = nullptr;
      return true;
    };

// This implementation does nothing.
ATTRIBUTE_WEAK
std::function<void(const altcp_allocator_t&)> qnethernet_altcp_free_allocator =
    [](const altcp_allocator_t& allocator) {
      (void)allocator;
    };

#endif  // LWIP_ALTCP && QNETHERNET_PROVIDE_ALTCP_DEFAULT_FUNCTIONS
