// SPDX-FileCopyrightText: (c) 2021-2026 Shawn Silverman <shawn@pobox.com>
// SPDX-License-Identifier: AGPL-3.0-or-later

// QMMDNS.cpp implements MDNS.
// This file is part of the QNEthernet library.

#include "qnethernet/QNMDNS.h"

#if LWIP_MDNS_RESPONDER

// C++ includes
#include <algorithm>
#include <cctype>
#include <cerrno>
#include <cstring>

#include "lwip/apps/mdns_priv.h"  // For struct mdns_service
#include "lwip/debug.h"
#include "lwip/err.h"
#include "qnethernet/platforms/pgmspace.h"

namespace qindesign {
namespace network {

// A reference to the singleton.
STATIC_INIT_DEFN(MDNSClass, MDNS);

void MDNSClass::srv_txt(struct mdns_service* const service,
                        void* const txt_userdata) {
  if (txt_userdata == nullptr) {
    return;
  }

  // Find the correct service function
  const auto* const instance = static_cast<MDNSClass*>(txt_userdata);
  const auto end = std::end(instance->slots_);
  const auto it = std::find_if(
      std::begin(instance->slots_), end, [service](const Service& s) {
        return s.equals(true, service->name, service->service,
                        static_cast<enum mdns_sd_proto>(service->proto),
                        service->port);
      });
  if (it == end) {
    return;
  }

  // Some SRVs seem to need a TXT record in order to appear
  if (it->getTXTFunc_ == nullptr) {
    const err_t err = mdns_resp_add_service_txtitem(service, "", 0);
    if (err != ERR_OK) {
      errno = err_to_errno(err);
    }
    return;
  }

  const std::vector<std::string> list = it->getTXTFunc_();
  if (list.empty()) {
    const err_t err = mdns_resp_add_service_txtitem(service, "", 0);
    if (err != ERR_OK) {
      errno = err_to_errno(err);
    }
    return;
  }

  for (const std::string& item : list) {
    const char* const txt = item.c_str();
    const auto len = static_cast<uint8_t>(
        std::min(item.length(), size_t{MDNS_LABEL_MAXLEN}));
    const err_t res = mdns_resp_add_service_txtitem(service, txt, len);
    LWIP_ERROR("mdns add service txt failed\n", (res == ERR_OK),
               errno = err_to_errno(res);
               return);
  }
}

static bool s_initialized = false;
static bool s_netifAdded = false;

FLASHMEM MDNSClass::~MDNSClass() noexcept {
  int lastErrno = errno;
  end();
  errno = lastErrno;  // Because end() may have set it via
                      // ConnectionManager::stopListening()
}

bool MDNSClass::begin(const char* const hostname) {
  if (netif_default == nullptr) {
    // Return false for no netif
    errno = ENOTCONN;
    return false;
  }

  if (!s_initialized) {
    mdns_resp_init();
    s_initialized = true;
  }

  // Treat nullptr hostname as not allowed
  if (hostname == nullptr) {
    errno = EINVAL;
    return false;
  }

  if (s_netifAdded) {
    if ((std::strlen(hostname_) == std::strlen(hostname)) &&
        (std::strncmp(hostname_, hostname, std::strlen(hostname_)) == 0)) {
      return true;
    }
    const err_t err = mdns_resp_rename_netif(netif_, hostname);
    if (err != ERR_OK) {
      errno = err_to_errno(err);
      return false;
    }
  } else {
    const err_t err = mdns_resp_add_netif(netif_default, hostname);
    if (err != ERR_OK) {
      errno = err_to_errno(err);
      return false;
    }

    s_netifAdded = true;
    netif_ = netif_default;
  }

  (void)std::strncpy(hostname_, hostname, sizeof(hostname_) - 1);
  hostname_[sizeof(hostname_) - 1] = '\0';
  return true;
}

void MDNSClass::end() {
  if (s_netifAdded) {
    const err_t err = mdns_resp_remove_netif(netif_);
    s_netifAdded = false;
    netif_ = nullptr;
    hostname_[0] = '\0';
    if (err != ERR_OK) {
      errno = err_to_errno(err);
    }
  }
}

void MDNSClass::restart() {
  if (!s_netifAdded) {
    return;
  }
  mdns_resp_restart(netif_);
}

// toProto converts a protocol to a protocol enum. This returns DNSSD_PROTO_TCP
// for "_tcp" and DNSSD_PROTO_UDP for all else.
ATTRIBUTE_NODISCARD
static enum mdns_sd_proto toProto(const char* const protocol) {
  if ((protocol != nullptr) && (std::strlen(protocol) == 4) &&
      (protocol[0] == '_') &&
      (std::tolower(protocol[1]) == 't') &&
      (std::tolower(protocol[2]) == 'c') &&
      (std::tolower(protocol[3]) == 'p')) {
    return mdns_sd_proto::DNSSD_PROTO_TCP;
  }
  return mdns_sd_proto::DNSSD_PROTO_UDP;
}

bool MDNSClass::addService(const char* const type, const char* const protocol,
                           uint16_t port) {
  return addService(hostname_, type, protocol, port, nullptr);
}

bool MDNSClass::addService(const char* const name, const char* const type,
                           const char* const protocol, const uint16_t port) {
  return addService(name, type, protocol, port, nullptr);
}

bool MDNSClass::addService(const char* const type, const char* const protocol,
                           const uint16_t port,
                           std::vector<std::string> (*const getTXTFunc)()) {
  return addService(hostname_, type, protocol, port, getTXTFunc);
}

bool MDNSClass::addService(const char* const name, const char* const type,
                           const char* const protocol, const uint16_t port,
                           std::vector<std::string> (*getTXTFunc)()) {
  if (!s_netifAdded) {
    // Return false for no netif
    errno = ENOTCONN;
    return false;
  }

  if ((name == nullptr) || (type == nullptr)) {
    errno = EINVAL;
    return false;
  }

  const enum mdns_sd_proto proto = toProto(protocol);

  const int8_t slot =
      mdns_resp_add_service(netif_, name, type, proto, port, &srv_txt,
                            static_cast<void*>(this));
  if (slot < 0) {
    errno = err_to_errno(slot);
    return false;
  } else if (static_cast<size_t>(slot) >= maxServices()) {
    // Remove if the addition was successful but we couldn't add it
    LWIP_ASSERT("Can't delete service",
                mdns_resp_del_service(netif_, slot) == ERR_OK);
    errno = ENOBUFS;
    return false;
  }

  slots_[slot].set(true, name, type, proto, port, getTXTFunc);
  return true;
}

internal::optional<uint8_t> MDNSClass::findService(const char* const name,
                                                   const char* const type,
                                                   const char* const protocol,
                                                   const uint16_t port) {
  for (size_t i = 0; i < maxServices(); ++i) {
    if (slots_[i].equals(true, name, type, toProto(protocol), port)) {
      return {true, static_cast<uint8_t>(i)};
    }
  }
  return {};
}

bool MDNSClass::removeService(const char* const type,
                              const char* const protocol,
                              const uint16_t port) {
  return removeService(hostname_, type, protocol, port);
}

bool MDNSClass::removeService(const char* const name, const char* const type,
                              const char* protocol, const uint16_t port) {
  if (!s_netifAdded) {
    // Return false for no netif
    return false;
  }

  if ((name == nullptr) || (type == nullptr)) {
    errno = EINVAL;
    return false;
  }

  // Find a matching service
  const auto found = findService(name, type, protocol, port);
  if (!found.has_value) {
    return false;
  }
  if (found.value < maxServices()) {
    slots_[found.value].reset();
  }

  const err_t err = mdns_resp_del_service(netif_, found.value);
  if (err != ERR_OK) {
    errno = err_to_errno(err);
    return false;
  }
  return true;
}

MDNSClass::operator bool() const {
  return netif_ != nullptr;
}

void MDNSClass::announce() const {
  if (!s_netifAdded) {
    errno = ENOTCONN;
    return;
  }
  mdns_resp_announce(netif_);
}

MDNSClass::Service::Service() {
  reset();
}

void MDNSClass::Service::set(bool valid, const char* name, const char* type,
                             enum mdns_sd_proto proto, uint16_t port,
                             std::vector<std::string> (*const getTXTFunc)()) {
  valid_ = valid;
  (void)std::strncpy(name_, name, sizeof(name_) - 1);
  name_[sizeof(name_) - 1] = '\0';
  (void)std::strncpy(type_, type, sizeof(type_) - 1);
  type_[sizeof(type_) - 1] = '\0';
  proto_ = proto;
  port_ = port;
  getTXTFunc_ = getTXTFunc;
}

bool MDNSClass::Service::equals(const bool valid, const char* const name,
                                const char* const type,
                                const enum mdns_sd_proto proto,
                                uint16_t port) const {
  if (!valid_ || !valid) {
    // Invalid services compare unequal
    return false;
  }

  // Don't compare the functions
  return (std::strncmp(name_, name, sizeof(name_)) == 0) &&
         (std::strncmp(type_, type, sizeof(type_)) == 0) &&
         (proto_ == proto) &&
         (port_ == port);
}

// Resets this service to be invalid and empty.
void MDNSClass::Service::reset() {
  valid_ = false;
  name_[0] = '\0';
  type_[0] = '\0';
  proto_ = mdns_sd_proto::DNSSD_PROTO_UDP;
  port_ = 0;
  getTXTFunc_ = nullptr;
}

}  // namespace network
}  // namespace qindesign

#endif  // LWIP_MDNS_RESPONDER
