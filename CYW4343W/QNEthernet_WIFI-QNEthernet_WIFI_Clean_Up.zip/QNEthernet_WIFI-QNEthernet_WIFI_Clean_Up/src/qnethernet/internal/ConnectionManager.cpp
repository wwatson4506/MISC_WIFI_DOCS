// SPDX-FileCopyrightText: (c) 2021-2026 Shawn Silverman <shawn@pobox.com>
// SPDX-License-Identifier: AGPL-3.0-or-later

// ConnectionManager.cpp implements the connection manager.
// This file is part of the QNEthernet library.

#include "qnethernet/internal/ConnectionManager.h"

#if LWIP_TCP

// C++ includes
#include <algorithm>
#include <cerrno>
#include <limits>

#include "QNEthernet.h"
#include "lwip/err.h"
#include "lwip/ip.h"
#if LWIP_ALTCP
#include "lwip/tcp.h"
#endif  // LWIP_ALTCP

#if LWIP_ALTCP
// This is a function that fills in the given 'altcp_allocator_t' with an
// allocator function and an argument. The values are used by 'altcp_new()' to
// create the appropriate socket type. This returns whether the allocator and
// argument were successfully created or assigned.
//
// The arguments indicate what the calling code is trying to do:
// 1. If ipaddr is NULL then the application is trying to listen.
// 2. If ipaddr is not NULL then the application is trying to connect.
//
// If the socket could not be created, then qnethernet_altcp_free_allocator() is
// called with the same allocator.
extern std::function<bool(const ip_addr_t* ipaddr, uint16_t port,
                          altcp_allocator_t& allocator)>
    qnethernet_altcp_get_allocator;

// This function is called if qnethernet_altcp_get_allocator() returns true and
// the socket could not be created. It is called with the same allocator as
// qnethernet_altcp_get_allocator(). This is an opportunity to free the argument
// if it has not already been freed.
extern std::function<void(const altcp_allocator_t& allocator)>
    qnethernet_altcp_free_allocator;
#endif  // LWIP_ALTCP

namespace qindesign {
namespace network {
namespace internal {

ConnectionManager& ConnectionManager::instance() {
  static ConnectionManager instance;
  return instance;
}

// Connection state callback.
err_t ConnectionManager::connectedFunc(void* const arg,
                                       struct altcp_pcb* const tpcb,
                                       const err_t err) {
  if (tpcb == nullptr) {
    return ERR_ARG;
  }

  const auto holder = static_cast<ConnectionHolder*>(arg);

  holder->lastError = err;
  holder->connected = (err == ERR_OK);

  if (err != ERR_OK) {
    holder->state = nullptr;

    if (err != ERR_CLSD) {
      if (altcp_close(tpcb) != ERR_OK) {
        altcp_abort(tpcb);
        return ERR_ABRT;
      }
    }
  }
  return ERR_OK;
}

// Check if there's data available in the buffer.
ATTRIBUTE_NODISCARD
static inline bool isAvailable(const std::unique_ptr<ConnectionState>& state) {
  return (/*(0 <= state->bufPos) &&*/ (state->bufPos < state->buf.size()));
}

// Copy any remaining data from the state to the "remaining" buffer. This first
// clears the 'remaining' buffer.
//
// This assumes holder->state != NULL.
static void maybeCopyRemaining(ConnectionHolder* const holder) {
  std::vector<uint8_t>& v = holder->remaining;
  const auto& state = holder->state;

  // Reset the 'remaining' buffer
  v.clear();
  holder->remainingPos = 0;

  if (isAvailable(state)) {
    (void)v.insert(v.cend(), state->buf.cbegin() + state->bufPos,
                   state->buf.cend());
  }
}

// Error callback.
void ConnectionManager::errFunc(void* const arg, const err_t err) {
  if (arg == nullptr) {
    return;
  }

  const auto holder = static_cast<ConnectionHolder*>(arg);

  holder->lastError = err;
  holder->connected = (err == ERR_OK);

  if ((holder->state != nullptr) && (err != ERR_OK)) {
    // Copy any buffered data
    maybeCopyRemaining(holder);

    holder->state = nullptr;
  }
}

// Data reception callback.
err_t ConnectionManager::recvFunc(void* const arg, struct altcp_pcb* const tpcb,
                                  struct pbuf* const p, const err_t err) {
  if (tpcb == nullptr) {
    return ERR_ARG;
  }

  const auto holder = static_cast<ConnectionHolder*>(arg);

  holder->lastError = err;

  struct pbuf* pNext = p;
  const auto& state = holder->state;

  // Check for errors and null packets
  // Null packets mean the connection is closed
  if ((p == nullptr) || (err != ERR_OK)) {
    holder->connected = false;

    if (state != nullptr) {
      // Copy any buffered data
      maybeCopyRemaining(holder);

      if (p != nullptr) {
        // Copy pbuf contents
        while (pNext != nullptr) {
          const auto data = static_cast<const uint8_t*>(pNext->payload);
          (void)holder->remaining.insert(holder->remaining.cend(), &data[0],
                                         &data[pNext->len]);
          pNext = pNext->next;
        }
      }
    }

    if (p != nullptr) {
      altcp_recved(tpcb, p->tot_len);
      (void)pbuf_free(p);
    }

    holder->state = nullptr;

    if (err != ERR_CLSD) {
      if (altcp_close(tpcb) != ERR_OK) {
        altcp_abort(tpcb);
        return ERR_ABRT;
      }
    }

    return ERR_OK;  // Return from error or closed connection
  }

  // We are connected
  // Copy all the data

  holder->connected = true;

  if (state != nullptr) {
    std::vector<uint8_t>& v = state->buf;

    // Check that we can store all the data
    const size_t rem = v.capacity() - v.size() + state->bufPos;
    if (rem < p->tot_len) {
      static_assert((std::numeric_limits<decltype(p->tot_len)>::max() <=
                     std::numeric_limits<uint16_t>::max()),
                    "Can't assume length doesn't overflow");
      // Note: Don't need to free the pbuf here because not returning
      //       ERR_OK or ERR_ABRT
      altcp_recved(tpcb, static_cast<uint16_t>(rem));  // p->tot_len is u16_t
      return ERR_INPROGRESS;  // ERR_MEM? Other?
    }

    // If there isn't enough space at the end, move all the data in the buffer
    // to the top
    if (v.capacity() - v.size() < p->tot_len) {
      const size_t n = v.size() - state->bufPos;
      if (n > 0) {
        // TODO: Use a ring buffer for performance?
        (void)std::copy_n(v.cbegin() + state->bufPos, n, v.begin());
        v.resize(n);
      } else {
        v.clear();
      }
      state->bufPos = 0;
    }

    // Copy all the data from the pbuf
    while (pNext != nullptr) {
      const auto data = static_cast<const uint8_t*>(pNext->payload);
      (void)v.insert(v.cend(), &data[0], &data[pNext->len]);
      pNext = pNext->next;
    }
  }

  altcp_recved(tpcb, p->tot_len);
  (void)pbuf_free(p);

  return ERR_OK;
}

// Accepted connection callback.
err_t ConnectionManager::acceptFunc(void* const arg,
                                    struct altcp_pcb* const newpcb,
                                    const err_t err) {
  if (newpcb == nullptr) {
    return ERR_ARG;
  }

  const auto m = static_cast<ConnectionManager*>(arg);

  if (err != ERR_OK) {
    if (err != ERR_CLSD) {
      if (altcp_close(newpcb) != ERR_OK) {
        altcp_abort(newpcb);
        return ERR_ABRT;
      }
    }
    return ERR_OK;
  }

  // Create and add the connection

  auto holder = std::make_shared<ConnectionHolder>();
  holder->lastError = err;
  holder->connected = true;
  // The following sets the ConnectionHolder* as the PCB's arg
  holder->state = compat::make_unique<ConnectionState>(newpcb, holder.get());
  holder->accepted = false;
  altcp_err(newpcb, &errFunc);
  altcp_recv(newpcb, &recvFunc);
  m->addConnection(holder);

  return ERR_OK;
}

void ConnectionManager::addConnection(
    const std::shared_ptr<ConnectionHolder>& holder) {
  connections_.push_back(holder);
  holder->state->removeFunc = [this, holder](ConnectionState* state) {
    (void)state;

    // Remove the connection from the list
    const auto it =
        std::find(connections_.cbegin(), connections_.cend(), holder);
    if (it != connections_.cend()) {
      (void)connections_.erase(it);
    }
  };
}

ATTRIBUTE_NODISCARD
static struct altcp_pcb* create_altcp_pcb(const ip_addr_t* const ipaddr,
                                          const uint16_t port,
                                          const uint8_t ip_type) {
#if LWIP_ALTCP
  struct altcp_pcb* pcb = nullptr;
  altcp_allocator_t allocator{nullptr, nullptr};
  if (qnethernet_altcp_get_allocator(ipaddr, port, allocator)) {
    pcb = altcp_new_ip_type(&allocator, ip_type);
    if (pcb == nullptr) {
      qnethernet_altcp_free_allocator(allocator);
    }
  }
  return pcb;
#else
  (void)ipaddr;
  (void)port;

  return altcp_new_ip_type(nullptr, ip_type);
#endif  // LWIP_ALTCP
}

std::shared_ptr<ConnectionHolder> ConnectionManager::connect(
    const ip_addr_t* const ipaddr, const uint16_t port) {
  if (ipaddr == nullptr) {
    Ethernet.loop();  // Allow the stack to move along
    return nullptr;
  }

  struct altcp_pcb* const pcb =
      create_altcp_pcb(ipaddr, port, IP_GET_TYPE(ipaddr));
  if (pcb == nullptr) {
    Ethernet.loop();  // Allow the stack to move along
    errno = ENOMEM;
    return nullptr;
  }

  // Try to bind
  err_t err = altcp_bind(pcb, IP_ANY_TYPE, 0);
  if (err != ERR_OK) {
    altcp_abort(pcb);
    Ethernet.loop();  // Allow the stack to move along
    errno = err_to_errno(err);
    return nullptr;
  }

  // Connect listeners
  auto holder = std::make_shared<ConnectionHolder>();
  // The following sets the ConnectionHolder* as the PCB's arg
  holder->state = compat::make_unique<ConnectionState>(pcb, holder.get());
  holder->accepted = true;
  altcp_err(pcb, &errFunc);
  altcp_recv(pcb, &recvFunc);

  // Try to connect
  err = altcp_connect(pcb, ipaddr, port, &connectedFunc);
  if (err != ERR_OK) {
    // holder->state will be removed when holder is removed
    altcp_abort(pcb);
    Ethernet.loop();  // Allow the stack to move along
    errno = err_to_errno(err);
    return nullptr;
  }

  addConnection(holder);
  return holder;
}

optional<uint16_t> ConnectionManager::listen(const uint16_t port,
                                             const bool reuse) {
  struct altcp_pcb* pcb = create_altcp_pcb(nullptr, port, IPADDR_TYPE_ANY);
  if (pcb == nullptr) {
    Ethernet.loop();  // Allow the stack to move along
    errno = ENOMEM;
    return {};
  }

  // Try to bind
  if (reuse) {
#if LWIP_ALTCP
    struct altcp_pcb* innermost = pcb;
    while (innermost->inner_conn != nullptr) {
      innermost = innermost->inner_conn;
    }
    ip_set_option(static_cast<struct tcp_pcb*>(innermost->state),
                  SOF_REUSEADDR);
#else
    ip_set_option(pcb, SOF_REUSEADDR);
#endif  // LWIP_ALTCP
  }
  err_t err = altcp_bind(pcb, IP_ANY_TYPE, port);
  if (err != ERR_OK) {
    altcp_abort(pcb);
    Ethernet.loop();  // Allow the stack to move along
    errno = err_to_errno(err);
    return {};
  }

  // Try to listen
  err = ERR_OK;
  struct altcp_pcb* const pcbNew =
      altcp_listen_with_backlog_and_err(pcb, TCP_DEFAULT_LISTEN_BACKLOG, &err);
  if (pcbNew == nullptr) {
    altcp_abort(pcb);
    Ethernet.loop();  // Allow the stack to move along
    errno = err_to_errno(err);
    return {};
  }
  pcb = pcbNew;

  // Finally, accept connections
  listeners_.push_back(pcb);
  altcp_arg(pcb, this);
  altcp_accept(pcb, &acceptFunc);

  uint16_t actualPort = port;
  if (port == 0) {
    LWIP_ASSERT(
        "Expected valid port",
        altcp_get_tcp_addrinfo(pcb, 1, nullptr, &actualPort) == ERR_OK);
  }
  return {true, actualPort};
}

// Gets the local port from the given tcp_pcb.
ATTRIBUTE_NODISCARD
static uint16_t getLocalPort(struct altcp_pcb* pcb) {
#if LWIP_ALTCP
  return altcp_get_port(pcb, 1);
#else
  uint16_t port;
  LWIP_ASSERT("Expected valid port",
              altcp_get_tcp_addrinfo(pcb, 1, nullptr, &port) == ERR_OK);
  return port;
#endif  // LWIP_ALTCP
}

bool ConnectionManager::isListening(const uint16_t port) const {
  const auto it =
      std::find_if(listeners_.cbegin(), listeners_.cend(),
                   [port](struct altcp_pcb* const elem) {
                     return (elem != nullptr) && (getLocalPort(elem) == port);
                   });
  return (it != listeners_.cend());
}

bool ConnectionManager::stopListening(const uint16_t port) {
  const auto it =
      std::find_if(listeners_.cbegin(), listeners_.cend(),
                   [port](struct altcp_pcb* const elem) {
                     return (elem != nullptr) && (getLocalPort(elem) == port);
                   });
  if (it == listeners_.cend()) {
    errno = ENOTCONN;
    return false;
  }
  struct altcp_pcb* const pcb = *it;
  (void)listeners_.erase(it);
  if (altcp_close(pcb) != ERR_OK) {
    altcp_abort(pcb);
    // Note: Don't set errno because we're returning true here
  }
  return true;
}

std::shared_ptr<ConnectionHolder> ConnectionManager::findUnacknowledged(
    const uint16_t port) const {
  const auto it = std::find_if(
      connections_.cbegin(), connections_.cend(),
      // Note: No 'auto' type for parameters in C++11
      [port](const std::shared_ptr<ConnectionHolder>& elem) {
        const auto& state = elem->state;
        return (state != nullptr) && !elem->accepted &&
               (getLocalPort(state->pcb) == port);
      });
  if (it != connections_.cend()) {
    return *it;
  }
  return nullptr;
}

// TODO: Should we implement some kind of fairness?
std::shared_ptr<ConnectionHolder> ConnectionManager::findAvailable(
    const uint16_t port) const {
  const auto it = std::find_if(
      connections_.cbegin(), connections_.cend(),
      // Note: No 'auto' type for parameters in C++11
      [port](const std::shared_ptr<ConnectionHolder>& elem) {
        const auto& state = elem->state;
        return (state != nullptr) &&
               (getLocalPort(state->pcb) == port) &&
               isAvailable(state);
      });
  if (it != connections_.cend()) {
    return *it;
  }
  return nullptr;
}

bool ConnectionManager::remove(
    const std::shared_ptr<ConnectionHolder>& holder) {
  const auto it = std::find(connections_.cbegin(), connections_.cend(), holder);
  if (it != connections_.cend()) {
    const auto& state = (*it)->state;
    if (state != nullptr) {
      state->removeFunc = nullptr;
    }
    (void)connections_.erase(it);
    return true;
  }
  return false;
}

size_t ConnectionManager::write(const uint16_t port, const uint8_t b) {
  return write(port, &b, 1);
}

size_t ConnectionManager::write(const uint16_t port,
                                const void* const b, const size_t len) {
  const auto size16 = static_cast<uint16_t>(
      std::min(len, size_t{std::numeric_limits<uint16_t>::max()}));
  iterateConnections([port, b, size16](struct altcp_pcb* pcb) {
    if (getLocalPort(pcb) != port) {
      return;
    }
    if (altcp_sndbuf(pcb) < size16) {
      if (altcp_output(pcb) != ERR_OK) {
        return;
      }
      // May invalidate connections_ iterators:
      // Ethernet.loop();
    }
    const uint16_t len = std::min(size16, altcp_sndbuf(pcb));
    if (len > 0) {
      // TODO: Is ignoring the return the correct thing to do?
      // Note: Writing to a single connection ignores the error (but sets errno)
      (void)altcp_write(pcb, b, len, TCP_WRITE_FLAG_COPY);
    }
  });
  Ethernet.loop();
  return size16;
}

void ConnectionManager::flush(const uint16_t port) {
  iterateConnections([port](struct altcp_pcb* pcb) {
    if (getLocalPort(pcb) != port) {
      return;
    }
    // TODO: Is ignoring the return the correct thing to do?
    // Note: Writing to a single connection ignores the error
    (void)altcp_output(pcb);
    // May invalidate connections_ iterators:
    // Ethernet.loop();
  });
  Ethernet.loop();
}

int ConnectionManager::availableForWrite(const uint16_t port) {
  uint16_t min = std::numeric_limits<uint16_t>::max();
  bool found = false;
  iterateConnections([port, &min, &found](struct altcp_pcb* pcb) {
    if (getLocalPort(pcb) != port) {
      return;
    }
    min = std::min(min, altcp_sndbuf(pcb));
    found = true;
  });
  if (!found) {
    return 0;
  }
  return min;
}

void ConnectionManager::abortAll() {
  iterateConnections([](struct altcp_pcb* pcb) { altcp_abort(pcb); });
}

void ConnectionManager::iterateConnections(
    std::function<void(struct altcp_pcb* pcb)> f) {
  if (connections_.empty()) {
    return;
  }

  // To avoid any re-entrant modifications, copy the existing list
  size_t count = 0;
  (void)std::for_each(
      connections_.cbegin(), connections_.cend(),
      // Note: No 'auto' type for parameters in C++11
      [this, &count](const std::shared_ptr<ConnectionHolder>& elem) {
        // TODO: Verify that connections_ can never contain more than MEMP_NUM_TCP_PCB
        if ((elem->state != nullptr) && (count < connSnapshot_.size())) {
          connSnapshot_[count++] = elem->state->pcb;
        }
      });

  // Now we can iterate more safely
  (void)std::for_each(connSnapshot_.cbegin(), connSnapshot_.cbegin() + count,
                      f);
}

void ConnectionManager::iterateListeners(
    std::function<void(struct altcp_pcb* pcb)> f) {
  if (listeners_.empty()) {
    return;
  }

  // To avoid any re-entrant modifications, copy the existing list
  size_t count = 0;
  (void)std::for_each(
      listeners_.cbegin(), listeners_.cend(),
      [this, &count](struct altcp_pcb* const pcb) {
        // TODO: Verify that listeners_ can never contain more than MEMP_NUM_TCP_PCB_LISTEN
        if (count < lstnSnapshot_.size()) {
          lstnSnapshot_[count++] = pcb;
        }
      });

  // Now we can iterate more safely
  (void)std::for_each(lstnSnapshot_.cbegin(), lstnSnapshot_.cbegin() + count,
                      f);
}

}  // namespace internal
}  // namespace network
}  // namespace qindesign

#endif  // LWIP_TCP
