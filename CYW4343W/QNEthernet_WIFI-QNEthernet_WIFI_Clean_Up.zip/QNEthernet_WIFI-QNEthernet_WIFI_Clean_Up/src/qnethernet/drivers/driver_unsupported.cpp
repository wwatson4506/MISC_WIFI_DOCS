// SPDX-FileCopyrightText: (c) 2021-2026 Shawn Silverman <shawn@pobox.com>
// SPDX-License-Identifier: AGPL-3.0-or-later

// driver_unsupported.c contains the unsupported Ethernet interface implementation.
// This file is part of the QNEthernet library.

#include "qnethernet/lwip_driver.h"

#include "lwip/err.h"
#include "qnethernet/platforms/pgmspace.h"

#if defined(QNETHERNET_INTERNAL_DRIVER_UNSUPPORTED)

extern "C" {

FLASHMEM void driver_get_capabilities(struct DriverCapabilities* const dc) {
  dc->isMACSettable                = false;
  dc->isLinkStateDetectable        = false;
  dc->isLinkSpeedDetectable        = false;
  dc->isLinkSpeedSettable          = false;
  dc->isLinkFullDuplexDetectable   = false;
  dc->isLinkFullDuplexSettable     = false;
  dc->isAutoNegotiationSettable    = false;
  dc->isLinkCrossoverDetectable    = false;
  dc->isAutoNegotiationRestartable = false;
  dc->isPHYResettable              = false;
}

bool driver_is_unknown() {
  return false;
}

void qnethernet_hal_get_system_mac_address(uint8_t mac[ETH_HWADDR_LEN]);

void driver_get_system_mac(uint8_t mac[ETH_HWADDR_LEN]) {
  qnethernet_hal_get_system_mac_address(mac);
}

bool driver_get_mac(uint8_t mac[ETH_HWADDR_LEN]) {
  driver_get_system_mac(mac);
  return true;
}

bool driver_set_mac(const uint8_t mac[ETH_HWADDR_LEN]) {
  (void)mac;

  return false;
}

bool driver_has_hardware() {
  return false;
}

void driver_set_chip_select_pin(const int pin) {
  (void) pin;
}

bool driver_init() {
  return false;
}

void driver_deinit() {
}

struct pbuf* driver_proc_input(struct netif* const netif, const int counter) {
  (void)netif;
  (void)counter;

  return NULL;
}

void driver_poll(struct netif* const netif) {
  (void)netif;
}

void driver_get_link_info(struct LinkInfo* const li) {
  (void)li;
}

bool driver_set_link(const struct LinkSettings* const ls) {
  (void)ls;

  return false;
}

err_t driver_output(struct pbuf* const p) {
  (void)p;

  return ERR_IF;
}

#if QNETHERNET_ENABLE_RAW_FRAME_SUPPORT
bool driver_output_frame(const void* const frame, const size_t len) {
  (void)frame;
  (void)len;

  return false;
}
#endif  // QNETHERNET_ENABLE_RAW_FRAME_SUPPORT

// --------------------------------------------------------------------------
//  MAC Address Filtering
// --------------------------------------------------------------------------

#if !QNETHERNET_ENABLE_PROMISCUOUS_MODE

bool driver_set_incoming_mac_address_allowed(const uint8_t mac[ETH_HWADDR_LEN],
                                             const bool allow) {
  (void)mac;
  (void)allow;

  return false;
}

#endif  // !QNETHERNET_ENABLE_PROMISCUOUS_MODE

// --------------------------------------------------------------------------
//  Notifications from Upper Layers
// --------------------------------------------------------------------------

void driver_notify_manual_link_state(const bool flag) {
  (void)flag;
}

// --------------------------------------------------------------------------
//  Link Functions
// --------------------------------------------------------------------------

void driver_restart_auto_negotiation() {
}

void driver_reset_phy() {
}

}  // extern "C"

#endif  // QNETHERNET_INTERNAL_DRIVER_UNSUPPORTED
