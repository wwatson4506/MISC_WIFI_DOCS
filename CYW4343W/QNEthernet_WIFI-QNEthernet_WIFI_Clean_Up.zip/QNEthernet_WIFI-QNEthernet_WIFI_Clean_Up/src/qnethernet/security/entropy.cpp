// SPDX-FileCopyrightText: (c) 2023-2026 Shawn Silverman <shawn@pobox.com>
// SPDX-License-Identifier: AGPL-3.0-or-later

// entropy.cpp implements the TRNG functions.
// This file is part of the QNEthernet library.

#include "qnethernet/security/entropy.h"

#include "qnethernet/compat/c++11_compat.h"

#if defined(TEENSYDUINO) && defined(__IMXRT1062__)
#if !QNETHERNET_USE_ENTROPY_LIB

// C++ includes
#include <algorithm>
#include <cerrno>
#include <cstring>

#include <imxrt.h>

#include "qnethernet/internal/macro_funcs.h"
#include "qnethernet/platforms/pgmspace.h"

enum TRNGValues {
  // Clock settings
  TRNG_CONFIG_CLOCK_MODE   = 0,  // 0=Ring Oscillator, 1=System Clock (test use only)
  TRNG_CONFIG_RING_OSC_DIV =     // Divide by 2^n
#if (F_CPU >= 528000000)
      0,
#else
      2,
#endif  // F_CPU range

  // Sampling
  TRNG_CONFIG_SAMPLE_MODE      = 2,  // 0:Von Neumann in both, 1:raw in both, 2:VN Entropy and raw in stats */
  TRNG_CONFIG_SPARSE_BIT_LIMIT = 63,

  // Seed control
  TRNG_CONFIG_ENTROPY_DELAY = 3200,
  TRNG_CONFIG_SAMPLE_SIZE   = 2500/*512*/,

  // Statistical check parameters
  TRNG_CONFIG_RETRY_COUNT   = 1,
  TRNG_CONFIG_RUN_MAX_LIMIT = 34/*32*/,

  TRNG_CONFIG_MONOBIT_MAX       = 1384/*317*/,
  TRNG_CONFIG_MONOBIT_RANGE     = 268/*122*/,
  TRNG_CONFIG_RUNBIT1_MAX       = 405/*107*/,
  TRNG_CONFIG_RUNBIT1_RANGE     = 178/*80*/,
  TRNG_CONFIG_RUNBIT2_MAX       = 220/*62*/,
  TRNG_CONFIG_RUNBIT2_RANGE     = 122/*55*/,
  TRNG_CONFIG_RUNBIT3_MAX       = 125/*39*/,
  TRNG_CONFIG_RUNBIT3_RANGE     = 88/*39*/,
  TRNG_CONFIG_RUNBIT4_MAX       = 75/*26*/,
  TRNG_CONFIG_RUNBIT4_RANGE     = 64/*26*/,
  TRNG_CONFIG_RUNBIT5_MAX       = 47/*18*/,
  TRNG_CONFIG_RUNBIT5_RANGE     = 46/*18*/,
  TRNG_CONFIG_RUNBIT6PLUS_MAX   = 47/*17*/,
  TRNG_CONFIG_RUNBIT6PLUS_RANGE = 46/*17*/,

  // Limits for statistical check of "Poker Test"
  TRNG_CONFIG_POKER_MAX   = 26912/*1600*/,
  TRNG_CONFIG_POKER_RANGE = 2467/*570*/,

  // Limits for statistical check of entropy sample frequency count
  TRNG_CONFIG_FREQUENCY_MAX = 25600/*30000*/,
  TRNG_CONFIG_FREQUENCY_MIN = 1600,

// Security configuration
  TRNG_CONFIG_LOCK = 0,
};

// Additional bit-setting functions
ATTRIBUTE_ALWAYS_INLINE
static inline uint32_t TRNG_SBLIM_SB_LIM(const uint32_t n) {
  return (n & 0x000003ff);
}
ATTRIBUTE_ALWAYS_INLINE
static inline uint32_t TRNG_PKRMAX_PKR_MAX(const uint32_t n) {
  return (n & 0x00ffffff);
}
ATTRIBUTE_ALWAYS_INLINE
static inline uint32_t TRNG_PKRRNG_PKR_RNG(const uint32_t n) {
  return (n & 0x0000ffff);
}
ATTRIBUTE_ALWAYS_INLINE
static inline uint32_t TRNG_FRQMAX_FRQ_MAX(const uint32_t n) {
  return (n & 0x003fffff);
}
ATTRIBUTE_ALWAYS_INLINE
static inline uint32_t TRNG_FRQMIN_FRQ_MIN(const uint32_t n) {
  return (n & 0x003fffff);
}
ATTRIBUTE_ALWAYS_INLINE
static inline uint32_t TRNG_SEC_CFG_NO_PROG(const uint32_t n) {
  return ((n & 0x01) << 1);
}

// Entropy storage
static constexpr size_t kEntropyCount      = 16;  // In dwords
static constexpr size_t kEntropyCountBytes = (kEntropyCount << 2);  // In bytes

static uint32_t s_entropy[kEntropyCount] DMAMEM;
static size_t s_entropySizeBytes = 0;  // Size in bytes

extern "C" bool trng_is_started() {
  // Two checks:
  // 1. Clock is running
  // 2. "OK to stop" bit: asserted if the ring oscillator isn't running
  return ((CCM_CCGR6 & CCM_CCGR6_TRNG(CCM_CCGR_ON)) != 0) &&
         ((TRNG_MCTL & TRNG_MCTL_TSTOP_OK) == 0);
}

// Restarts entropy generation.
static void restartEntropy() {
  TRNG_ENT15;
  TRNG_ENT0;  // Dummy read for defect workaround
  s_entropySizeBytes = 0;
}

extern "C" {

FLASHMEM void trng_init() {
  // Enable the clock
  CCM_CCGR6 |= CCM_CCGR6_TRNG(CCM_CCGR_ON);

  // Set program mode, clear pending errors, reset registers to default
  TRNG_MCTL = TRNG_MCTL_PRGM | TRNG_MCTL_ERR | TRNG_MCTL_RST_DEF;

  // Apply configuration
  TRNG_SCMISC = TRNG_SCMISC_RTY_CT(TRNG_CONFIG_RETRY_COUNT) |
                TRNG_SCMISC_LRUN_MAX(TRNG_CONFIG_RUN_MAX_LIMIT);
  TRNG_SCML   = TRNG_SCML_MONO_RNG(TRNG_CONFIG_MONOBIT_RANGE) |
                TRNG_SCML_MONO_MAX(TRNG_CONFIG_MONOBIT_MAX);
  TRNG_SCR1L  = TRNG_SCR1L_RUN1_RNG(TRNG_CONFIG_RUNBIT1_RANGE) |
                TRNG_SCR1L_RUN1_MAX(TRNG_CONFIG_RUNBIT1_MAX);
  TRNG_SCR2L  = TRNG_SCR1L_RUN1_RNG(TRNG_CONFIG_RUNBIT2_RANGE) |
                TRNG_SCR1L_RUN1_MAX(TRNG_CONFIG_RUNBIT2_MAX);
  TRNG_SCR3L  = TRNG_SCR1L_RUN1_RNG(TRNG_CONFIG_RUNBIT3_RANGE) |
                TRNG_SCR1L_RUN1_MAX(TRNG_CONFIG_RUNBIT3_MAX);
  TRNG_SCR4L  = TRNG_SCR1L_RUN1_RNG(TRNG_CONFIG_RUNBIT4_RANGE) |
                TRNG_SCR1L_RUN1_MAX(TRNG_CONFIG_RUNBIT4_MAX);
  TRNG_SCR5L  = TRNG_SCR1L_RUN1_RNG(TRNG_CONFIG_RUNBIT5_RANGE) |
                TRNG_SCR1L_RUN1_MAX(TRNG_CONFIG_RUNBIT5_MAX);
  TRNG_SCR6PL = TRNG_SCR1L_RUN1_RNG(TRNG_CONFIG_RUNBIT6PLUS_RANGE) |
                TRNG_SCR1L_RUN1_MAX(TRNG_CONFIG_RUNBIT6PLUS_MAX);
  TRNG_PKRMAX = TRNG_PKRMAX_PKR_MAX(TRNG_CONFIG_POKER_MAX);
  TRNG_PKRRNG = TRNG_PKRRNG_PKR_RNG(TRNG_CONFIG_POKER_RANGE);
  TRNG_FRQMAX = TRNG_FRQMAX_FRQ_MAX(TRNG_CONFIG_FREQUENCY_MAX);
  TRNG_FRQMIN = TRNG_FRQMIN_FRQ_MIN(TRNG_CONFIG_FREQUENCY_MIN);

  // Clock settings
  clearAndSet32(&TRNG_MCTL,
                TRNG_MCTL_FOR_SCLK,
                TRNG_CONFIG_CLOCK_MODE ? TRNG_MCTL_FOR_SCLK : 0);
  clearAndSet32(&TRNG_MCTL,
                TRNG_MCTL_OSC_DIV(3),
                TRNG_MCTL_OSC_DIV(TRNG_CONFIG_RING_OSC_DIV));

  // Sampling
  clearAndSet32(&TRNG_MCTL,
                TRNG_MCTL_SAMP_MODE(3),
                TRNG_MCTL_SAMP_MODE(TRNG_CONFIG_SAMPLE_MODE));
  TRNG_SBLIM = TRNG_SBLIM_SB_LIM(TRNG_CONFIG_SPARSE_BIT_LIMIT);

  // Seed control
  TRNG_SDCTL = TRNG_SDCTL_ENT_DLY(TRNG_CONFIG_ENTROPY_DELAY) |
               TRNG_SDCTL_SAMP_SIZE(TRNG_CONFIG_SAMPLE_SIZE);

  // clearAndSet32(&TRNG_SCMISC, TRNG_SCMISC_LRUN_MAX, TRNG_CONFIG_RUN_MAX_LIMIT);

  // Security configuration
  clearAndSet32(&TRNG_SEC_CFG,
                TRNG_SEC_CFG_NO_PROG(1),
                TRNG_SEC_CFG_NO_PROG(TRNG_CONFIG_LOCK));

  clearAndSet32(&TRNG_MCTL, TRNG_MCTL_PRGM, 0);

  // Discard stale data
  restartEntropy();
}

FLASHMEM void trng_deinit() {
  TRNG_MCTL |= TRNG_MCTL_PRGM;  // Move to program mode; stop entropy generation

  // Check this bit before stopping the clock
  while ((TRNG_MCTL & TRNG_MCTL_TSTOP_OK) == 0) {
    // Wait
  }

  CCM_CCGR6 &= ~CCM_CCGR6_TRNG(CCM_CCGR_ON);  // Disable the clock
}

}  // extern "C"

// Copies entropy into the local entropy buffer. It is assumed there's entropy
// available. This checks for an error, and if there is one, returns false.
ATTRIBUTE_NODISCARD
static bool fillEntropyBuf() {
  // Check for an error
  if ((TRNG_MCTL & TRNG_MCTL_ERR) != 0) {
    clearAndSet32(&TRNG_MCTL, TRNG_MCTL_ERR, TRNG_MCTL_ERR);  // Clear error
    return false;
  }

  // Fill the array
  volatile uint32_t* addr = &TRNG_ENT0;
  for (size_t i = 0; i < kEntropyCount; ++i) {
    s_entropy[i] = *(addr++);
  }
  TRNG_ENT0;  // Dummy read after TRNG_ENT15 for defect workaround (according to SDK)
  s_entropySizeBytes = kEntropyCountBytes;

  return true;
}

// Fills the entropy pool if empty. This waits for entropy to be available or
// an error.
ATTRIBUTE_NODISCARD
static bool fillEntropy() {
  if (s_entropySizeBytes != 0) {
    return true;
  }

  // Wait for either Valid or Error flag
  while ((TRNG_MCTL & (TRNG_MCTL_ENT_VAL | TRNG_MCTL_ERR)) == 0) {
  }

  return fillEntropyBuf();
}

// // Reads a single entropy byte.
// ATTRIBUTE_NODISCARD
// static bool readEntropy(uint8_t* b) {
//   if (!fillEntropy()) {
//     return false;
//   }
//   *b = (reinterpret_cast<uint8_t*>(
//       s_entropy))[kEntropyCountBytes - (s_entropySizeBytes--)];
//   return true;
// }

extern "C" {

size_t trng_available() {
  if (s_entropySizeBytes == 0) {
    // Check for Valid
    if ((TRNG_MCTL & TRNG_MCTL_ENT_VAL) == 0) {
      return 0;
    }
    if (!fillEntropyBuf()) {
      return 0;
    }
  }

  return s_entropySizeBytes;
}

size_t trng_data(void* const data, const size_t size) {
  // After a deep sleep exit, some error bits are set in MCTL and must be
  // cleared before continuing. Also, trigger new entropy generation to be sure
  // there's fresh bits.
  if ((TRNG_MCTL & TRNG_MCTL_ERR) != 0) {
    clearAndSet32(&TRNG_MCTL, TRNG_MCTL_ERR, TRNG_MCTL_ERR);  // Clear error

    // Restart entropy generation
    restartEntropy();
  }

  uint8_t* p = static_cast<uint8_t*>(data);
  size_t rem = size;

  while (rem != 0) {
    if (!fillEntropy()) {
      return size - rem;
    }
    const size_t toCopy = std::min(rem, s_entropySizeBytes);
    (void)std::memcpy(p,
                      &(reinterpret_cast<uint8_t*>(
                          s_entropy))[kEntropyCountBytes - s_entropySizeBytes],
                      toCopy);
    p += toCopy;
    s_entropySizeBytes -= toCopy;
    rem -= toCopy;
  }

  return size;
}

}  // extern "C"

// Gathers a 32-bit random number and returns whether successful. This assumes
// that the argument is not NULL.
ATTRIBUTE_NODISCARD
static inline bool random32(uint32_t* const r) {
  return (trng_data(r, sizeof(*r)) == sizeof(*r));
}

extern "C" {

uint32_t entropy_random() {
  uint32_t r;
  if (!random32(&r)) {
    errno = EAGAIN;
    return 0;
  }
  return r;
}

uint32_t entropy_random_range(const uint32_t range) {
  if (range == 0) {
    errno = EDOM;
    return 0;
  }

  uint32_t r;
  if (!random32(&r)) {
    errno = EAGAIN;
    return 0;
  }

  // Is power of 2?
  if ((range & (range - 1)) == 0) {
    return r & (range - 1);
  }

  // Daniel Lemire's nearly-divisionless algorithm
  // https://lemire.me/blog/2019/09/28/doubling-the-speed-of-stduniform_int_distribution-in-the-gnu-c-library/
  // Note: There's not much impact if entropy generation takes much longer
  //       than division.
  uint64_t product = uint64_t{r} * uint64_t{range};
  uint32_t low = static_cast<uint32_t>(product);
  if (low < range) {  // Application of the rejection method
    const uint32_t threshold = -range % range;  // 2^L mod s = (2^L − s) mod s
    while (low < threshold) {
      if (!random32(&r)) {
        errno = EAGAIN;
        return 0;
      }
      product = uint64_t{r} * uint64_t{range};
      low = static_cast<uint32_t>(product);
    }
  }
  return static_cast<uint32_t>(product >> 32);
}

}  // extern "C"

/*

Reset values:
TRNG_SCML: 010C0568h
TRNG_SCML_MONO_RNG[31:16](268) | [sdk_2.14.0: 122] [lib:  268]
TRNG_SCML_MONO_MAX[15:0](1384)   [sdk_2.14.0: 317] [lib: 1384]

TRNG_SCR1L: 00B20195h
TRNG_SCR1L_RUN1_RNG[30:16](178) | [sdk_2.14.0:  80] [lib: 178]
TRNG_SCR1L_RUN1_MAX[14:0](405)    [sdk_2.14.0: 107] [lib: 405]

TRNG_SCR2L: 007A00DCh
TRNG_SCR2L_RUN2_RNG[29:16](122) | [sdk_2.14.0: 55] [lib: 122]
TRNG_SCR2L_RUN2_MAX[13:0](220)    [sdk_2.14.0: 62] [lib: 220]

TRNG_SCR3L: 0058007Dh
TRNG_SCR3L_RUN3_RNG[28:16](88) | [sdk_2.14.0: 39] [lib:  88]
TRNG_SCR3L_RUN3_MAX[12:0](125)   [sdk_2.14.0: 39] [lib: 125]

TRNG_SCR4L: 0040004Bh
TRNG_SCR4L_RUN4_RNG[27:16](64) | [sdk_2.14.0: 26] [lib: 64]
TRNG_SCR4L_RUN4_MAX[11:0](75)    [sdk_2.14.0: 26] [lib: 75]

TRNG_SCR5L: 002E002Fh
TRNG_SCR5L_RUN5_RNG[26:16](46) | [sdk_2.14.0: 18] [lib: 46]
TRNG_SCR5L_RUN5_MAX[10:0](47)    [sdk_2.14.0: 18] [lib: 47]

TRNG_SCR6PL: 002E002Fh
TRNG_SCR6PL_RUN6P_RNG[26:16](46) | [sdk_2.14.0: 17] [lib: 46]
TRNG_SCR6PL_RUN6P_MAX[10:0](47)    [sdk_2.14.0: 17] [lib: 47]

TRNG_PKRMAX[23:0]: 00006920h
26912 [sdk_2.14.0: 1600] [lib: 26912]

TRNG_PKRRNG[15:0]: 000009A3h
2467 [sdk_2.14.0: 570] [lib: 2467]

TRNG_FRQMAX[21:0]: 00006400h
25600 [sdk_2.14.0: 30000] [lib: 25600]

TRNG_FRQMIN[21:0]: 00000640h [? 00000000h in test]
1600 [0] [sdk_2.14.0: 1600] [lib: 1600]
bits

TRNG_MCTL: 00012001h [? 00012601h in test]
TRNG_MCTL_PRGM[16] |
TRNG_MCTL_LRUN_CONT[14](0) |
TRNG_MCTL_TSTOP_OK[13] |
TRNG_MCTL_ERR[12](0) |
TRNG_MCTL_TST_OUT[11](0) |
TRNG_MCTL_FCT_FAIL[8](0) |
TRNG_MCTL_FOR_SCLK[7](0) |
TRNG_MCTL_RST_DEF[6](0) |
TRNG_MCTL_SAMP_MODE[1:0](1) | [sdk_2.14.0: raw(1) in examples, 0 in HAL] [lib: 2]
TRNG_MCTL_OSC_DIV[3:2](0) |
[TRNG_MCTL_ENT_VAL | TRNG_MCTL_FCT_VAL]

TRNG_SDCTL: 0C8009C4h [? 032009c4h in test]
TRNG_SDCTL_ENT_DLY[31:16](3200) | [800] [sdk_2.14.0: 3200] [lib: 3200]
TRNG_SDCTL_SAMP_SIZE[15:0](2500)        [sdk_2.14.0:  512] [lib: 2500]

TRNG_SBLIM[9:0]: 0000003F
63 [sdk_2.14.0: 63] [lib: 63]

TRNG_SCMISC: 0001001Fh [? 00010022h in test]
TRNG_SCMISC_RTY_CT[19:16](1) |     [sdk_2.14.0:  1] [lib:  1]
TRNG_SCMISC_LRUN_MAX[7:0](31) [34] [sdk_2.14.0: 32] [lib: 34]

TRNG_ENT: 0

TRNG_SEC_CFG: 0
TRNG_SEC_CFG_NO_PRGM[1](0) [sdk_2.14.0: 0]

-----
TRNG_MCTL values only writable when PRGM is set:
FOR_SCLK[7] (RW)
RST_DEF[6] (WO)
OSC_DIV[3:2] (RW)
SAMP_MODE[1:0] (RW)

Other MCTL bits:
PRGM[16] (RW)
TSTOP_OK[13] (RO)
ERR[12] (W1C)
ENT_VAL[10] (RO)
TRNG_ACC[5] (RW) <-- Doesn't exist on this chip

*/

#endif  // !QNETHERNET_USE_ENTROPY_LIB
#endif  // defined(TEENSYDUINO) && defined(__IMXRT1062__)
