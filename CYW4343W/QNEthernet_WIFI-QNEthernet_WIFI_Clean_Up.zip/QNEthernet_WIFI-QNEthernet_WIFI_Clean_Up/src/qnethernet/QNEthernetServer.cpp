// SPDX-FileCopyrightText: (c) 2021-2026 Shawn Silverman <shawn@pobox.com>
// SPDX-License-Identifier: AGPL-3.0-or-later

// QNEthernetServer.cpp contains the EthernetServer implementation.
// This file is part of the QNEthernet library.

#include "qnethernet/QNEthernetServer.h"

#if LWIP_TCP

// C++ includes
#include <cerrno>
#include <memory>

#include "QNEthernet.h"
#include "qnethernet/internal/ConnectionManager.h"

namespace qindesign {
namespace network {

EthernetServer::EthernetServer(const uint16_t port)
    : port_{true, port} {}

EthernetServer::~EthernetServer() noexcept {
  int lastErrno = errno;
  end();
  errno = lastErrno;  // Because end() may have set it via
                      // ConnectionManager::stopListening()
}

int32_t EthernetServer::port() const {
  if (!port_.has_value) {
    return -1;
  }
  return (listeningPort_ > 0) ? listeningPort_ : port_.value;
}

void EthernetServer::begin() {
  if (!port_.has_value) {
    return;
  }
  (void)begin(port_.value, false);
}

bool EthernetServer::beginWithReuse() {
  if (!port_.has_value) {
    return false;
  }
  return begin(port_.value, true);
}

bool EthernetServer::begin(const uint16_t port) {
  return begin(port, false);
}

bool EthernetServer::beginWithReuse(const uint16_t port) {
  return begin(port, true);
}

bool EthernetServer::begin(const uint16_t port, const bool reuse) {
  // Only call end() if parameters have changed
  if (listeningPort_ > 0) {
    // If the request port is zero then choose another port
    if ((port != 0) && (port_ == port) && (reuse_ == reuse)) {
      return true;
    }
    int lastErrno = errno;
    end();  // TODO: Should we call end() only if the new begin is successful?
    errno = lastErrno;  // Because end() may have set it via
                        // ConnectionManager::stopListening()
  }

  // Only change the port if listening was successful
  const auto p = internal::ConnectionManager::instance().listen(port, reuse);
  if (p.has_value && p.value > 0) {
    listeningPort_ = p.value;
    port_ = {true, (port == 0) ? uint16_t{0} : p.value};
    reuse_ = reuse;
    return true;
  }
  // Note: errno set by listen()
  return false;
}

void EthernetServer::end() {
  if (listeningPort_ > 0) {
    (void)internal::ConnectionManager::instance().stopListening(listeningPort_);
    listeningPort_ = 0;
    // Note: errno set by stopListening()
  }
  // Don't unset the port if it's set:
  // port_ = {false, 0};
}

EthernetClient EthernetServer::accept() const {
  if (listeningPort_ > 0) {
    const auto conn =
        internal::ConnectionManager::instance().findUnacknowledged(
            listeningPort_);
    Ethernet.loop();
    if (conn != nullptr) {
      conn->accepted = true;
      return EthernetClient{conn};
    }
  }
  return EthernetClient{};
}

EthernetClient EthernetServer::available() const {
  if (listeningPort_ > 0) {
    const auto conn =
        internal::ConnectionManager::instance().findAvailable(listeningPort_);
    Ethernet.loop();
    if (conn != nullptr) {
      return EthernetClient{conn};
    }
  }
  return EthernetClient{};
}

EthernetServer::operator bool() const {
  return listeningPort_ > 0;
}

size_t EthernetServer::write(const uint8_t b) {
  if (listeningPort_ == 0) {
    return 1;
  }
  return internal::ConnectionManager::instance().write(listeningPort_, b);
}

size_t EthernetServer::write(const uint8_t* const buffer, const size_t size) {
  if (listeningPort_ == 0) {
    return size;
  }
  return internal::ConnectionManager::instance().write(listeningPort_,
                                                       buffer, size);
}

int EthernetServer::availableForWrite() {
  if (listeningPort_ == 0) {
    return 0;
  }
  return internal::ConnectionManager::instance().availableForWrite(
      listeningPort_);
}

void EthernetServer::flush() {
  if (listeningPort_ == 0) {
    return;
  }
  internal::ConnectionManager::instance().flush(listeningPort_);
}

}  // namespace network
}  // namespace qindesign

#endif  // LWIP_TCP
